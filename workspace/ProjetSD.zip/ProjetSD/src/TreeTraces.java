package senCity;

public class TreeTraces extends AbstractTraces {
	
	Node node;
	int size;
	public TreeTraces (Node node, int size){
		this.node = node;
		this.size = size;
	}
	
	public void AddLetter(char letter){
		Node nodeCourante = this.node;
		while(nodeCourante.getLetter() != letter){
			if (nodeCourante.getBrother() != null){
				nodeCourante = nodeCourante.getBrother();
			} else {
				Node newNode = new Node(letter, null, null, null); /* ATTENTION IL FAUDRA GENERER 
				LA LISTE DES TRACES CORESPONDANTE AU SSID DU MOT CORRESPONDANT AU CHEMIN DES
				LETTRES ALLANT DU SOMMET DE L'ARBRE A CETTE NODE*/
				nodeCourante.setBrother(newNode);
			}
		}
	}
	
	public void AddMot(String mot){
		Node nodeCourante = this.node;
		for (int i=1;i<=mot.length();i++){
			AddLetter(mot.charAt(i-1));
			while (nodeCourante.getLetter() != mot.charAt(i-1)){
					nodeCourante = nodeCourante.getBrother();
			}
			if (nodeCourante.getChild()!=null){
				nodeCourante = nodeCourante.getChild();
			} else {
				Node newNode = new Node(mot.charAt(i), null, null, null);
				nodeCourante.setChild(newNode);
				nodeCourante = newNode;
			}
		}
	}
	
	public boolean isInTree(String mot){
		Node nodeCourante = this.node;
		for(int i=0;i<mot.length()-1; i++) {
			while(nodeCourante.getLetter() != mot.charAt(i)){
				if (nodeCourante.getBrother() != null){
					nodeCourante = nodeCourante.getBrother();
				} else {
					return false;
				}
			}
			if(nodeCourante.getLetter() == mot.charAt(i)){
				nodeCourante = nodeCourante.getChild();
			}
		}
		return true;
	}

	@Override
	public void initialiser() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void ajouter(Trace trace) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Traces extract(String ssid) {
		// TODO Auto-generated method stub
		return null;
	}

}
