package senCity;

public class Node {

	char letter;
	Node child;
	Node brother;
	ArrayListTraces ListeTraces = new ArrayListTraces();
	
	public Node(char letter, Node child, Node brother, ArrayListTraces ListeTraces){
		this.letter=letter;
		this.child = child;
		this.brother = brother;
		this.ListeTraces = ListeTraces;
	}

	public ArrayListTraces getListeTraces() {
		return ListeTraces;
	}

	public void setListeTraces(ArrayListTraces listeTraces) {
		ListeTraces = listeTraces;
	}

	public char getLetter() {
		return letter;
	}

	public void setLetter(char letter) {
		this.letter = letter;
	}

	public Node getChild() {
		return child;
	}

	public void setChild(Node child) {
		this.child = child;
	}

	public Node getBrother() {
		return brother;
	}

	public void setBrother(Node brother) {
		this.brother = brother;
	}
	
	

}
