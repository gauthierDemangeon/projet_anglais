import java.io.* ;
import java.util.ArrayList ;
import java.util.Collection;


public class ArrayListTraces extends Traces
{
	
	public void initialiser() {
		Tracelist = new ArrayList<Trace>();
	}
	@Override
	public ArrayList<Trace> extract(String ssid) 
	{
		ArrayList<Trace> traces = new ArrayList<Trace>();
		for(Trace t:Tracelist)
		{
			if(t.getSsid().equals(ssid))
				traces.add(t);
		}
		return traces;
	}
	public static void main (String [] args) throws IOException 
	{
		ArrayListTraces trace = new ArrayListTraces();
		trace.Load("capture_wifi.csv","capture_gps.csv",70);
		System.out.println(trace.toString());
		trace.Save("data.txt");
	}
}
