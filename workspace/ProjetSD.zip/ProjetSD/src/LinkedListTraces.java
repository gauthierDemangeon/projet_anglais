import java.io.* ;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList ;


public class LinkedListTraces extends Traces
{
	
	public void initialiser() {
		Tracelist = new LinkedList<Trace>();
	}


	@Override
	public LinkedList<Trace> extract(String ssid) {
		LinkedList<Trace> traces = new LinkedList<Trace>();
		for(Trace t:Tracelist)
		{
			if(t.getSsid().equals(ssid))
				traces.add(t);
		}
		return traces;
	}
	
	public static void main (String [] args) throws IOException 
	{
		LinkedListTraces trace = new LinkedListTraces();
		trace.Load("capture_wifi.csv","capture_gps.csv",70);
		System.out.println(trace.toString());
		trace.Save("data.txt");
	}
}
