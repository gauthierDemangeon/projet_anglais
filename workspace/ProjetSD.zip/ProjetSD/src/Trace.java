

public class Trace 
{
	
	private long timestamp;
	private String ssid;
	private int signal;
	private GPS gps;
	
	public String getSsid() {
		return ssid;
	}

	public void setSsid(String ssid) {
		this.ssid = ssid;
	}
	
	public Trace(long timestamp, String ssid, int signal, GPS gps) 
	{
		this.timestamp = timestamp;
		this.ssid = ssid;
		this.signal = signal;
		this.gps = gps;
	}
	
	@Override
	public String toString() 
	{
		return "Trace [timestamp=" + timestamp + ", ssid=" + ssid + ", signal="
				+ signal + ", donn�es GPS="+gps.toString() + "]";
	}
	
}
